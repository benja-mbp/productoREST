package com.benja.productosRest.rest.logic;

import com.benja.productosRest.rest.modelo.Producto;
//import com.benja.productosRest.rest.modelo.dto.CreateProductoDTO;
//import com.benja.productosRest.rest.modelo.dto.ProductoDTO;

public interface ProductoService {

	public Producto crearProducto(Producto nuevo);
}
