package com.benja.productosRest.rest.error;



import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.fasterxml.jackson.databind.JsonMappingException;

@RestControllerAdvice
public class GlobalControllerAdvice extends ResponseEntityExceptionHandler{

	 @ExceptionHandler(ProductoNotFoundException.class)
	 public ResponseEntity<ApiError> handleProductoNoEncontrado(ProductoNotFoundException ex){
		 // Esta clase antes la teníamos en el Controller, ahora globalizamos los errores para su uso
//		 ApiError apiError = new ApiError();
//		 apiError.setEstado(HttpStatus.NOT_FOUND);
//		 apiError.setFecha(LocalDateTime.now());
//		 apiError.setMensaje(ex.getMessage());
//		 return ResponseEntity.status(HttpStatus.NOT_FOUND).body(apiError);
		 ApiError apiError = new ApiError(HttpStatus.NOT_FOUND, ex.getMessage());
		 return ResponseEntity.status(HttpStatus.NOT_FOUND).body(apiError);
	 }

	@Override
	protected ResponseEntity<Object> handleExceptionInternal(Exception ex, Object body, HttpHeaders headers,
			HttpStatus status, WebRequest request) {
		// TODO Auto-generated method stub
		//return super.handleExceptionInternal(ex, body, headers, status, request);
		ApiError apiError = new ApiError(status, ex.getMessage());
		return ResponseEntity.status(status).headers(headers).body(apiError);
		}
	 
	 
	 
//	 @ExceptionHandler(JsonMappingException.class)
//	 public ResponseEntity<ApiError> handleJsonMappingException(JsonMappingException ex){
////		 ApiError apiError = new ApiError();
////		 apiError.setEstado(HttpStatus.BAD_REQUEST);
////		 apiError.setFecha(LocalDateTime.now());
////		 apiError.setMensaje(ex.getMessage());
////		 return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(apiError);
//		 ApiError apiError = new ApiError(HttpStatus.BAD_REQUEST, ex.getMessage());
//		 return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(apiError);
//	 }
}
