package com.benja.productosRest.rest.logic;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.benja.productosRest.rest.modelo.Producto;
import com.benja.productosRest.rest.repository.ProductoRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ProductoServiceImpl implements ProductoService {
	
	@Autowired
	private ProductoRepository productoRepositorio;
	//@Autowired
	//private CategoriaRepository categoriaRepositorio;
	
	//private final ProductoDTOConverter productoDTOConverter;
	
	public Producto crearProducto(Producto nuevo) {
		return productoRepositorio.save(nuevo);
	}	
}
