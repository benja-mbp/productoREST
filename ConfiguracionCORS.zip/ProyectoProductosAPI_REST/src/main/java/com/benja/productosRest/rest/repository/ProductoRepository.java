package com.benja.productosRest.rest.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.benja.productosRest.rest.modelo.Producto;

public interface ProductoRepository extends JpaRepository<Producto, Long> {

}
