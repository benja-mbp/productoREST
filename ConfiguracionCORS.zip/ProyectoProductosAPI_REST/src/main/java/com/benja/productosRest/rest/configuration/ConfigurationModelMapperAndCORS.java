package com.benja.productosRest.rest.configuration;

import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class ConfigurationModelMapperAndCORS {
	@Bean
	public ModelMapper modelMapper() {
		return new ModelMapper();
	}
	
	@Bean
	public WebMvcConfigurer corsConfigurer() {
		return new WebMvcConfigurer() {
			
			@Override
			public void addCorsMappings(CorsRegistry registry) {
				//registry.addMapping("/**");  // permitiríamos peticiones de cualquier tipo
				// A continuación hacemos una configuración más concreta
				registry.addMapping("/producto/**") // solo para la ruta de producto
				.allowedOrigins("http://localhoost:9001") // solo permitimos la conexión desde esa ruta de cliente
				.allowedMethods("GET", "POST", "PUT", "DELETE") //podríamos añadir más métodos si quisieramos
				.maxAge(3600); // indica la caché máxima
			}
			
		};
	}
	
	@Bean
	public WebMvcConfigurer corsConfigurer2() {
		return new WebMvcConfigurer() {
			
			@Override
			public void addCorsMappings(CorsRegistry registry) {
				
				registry.addMapping("/producto/**") // solo damos acceso la ruta producto
				.allowedOrigins("*") // permitimos acceso desde cualquier origen
				.allowedMethods("GET") // solo permitimos GET
				.maxAge(1800); // cache por defecto de 30 minutos
			}
			
		};
	}
	
	
	
	/*
	 *Otra forma deprecada, obsoleta, de crear una clase para manejar CORS / en el controller podemos ver
	 *Otras dos formas, anivel de anotación de método y anotación de clase 
	 *
	 * @Configuration
	 * 
	 * @EnableWebMvc public class WebConfig extends WebMvcConfigurerAdapter {
	 * 
	 * @Override public void addCorsMappings(CorsRegistry registry) { } }
	 * registry.addMapping("/**");
	 * }
	 * }
	 */
}
	
	

