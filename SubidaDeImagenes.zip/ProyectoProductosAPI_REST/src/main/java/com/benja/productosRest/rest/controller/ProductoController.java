package com.benja.productosRest.rest.controller;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;

import com.benja.productosRest.rest.error.ApiError;
import com.benja.productosRest.rest.error.ProductoNotFoundException;
//import com.benja.productosRest.rest.logic.ProductoService;
//import com.benja.productosRest.rest.modelo.Categoria;
import com.benja.productosRest.rest.modelo.Producto;
import com.benja.productosRest.rest.modelo.dto.CreateProductoDTO;
import com.benja.productosRest.rest.modelo.dto.ProductoDTO;
import com.benja.productosRest.rest.modelo.dto.converter.ProductoDTOConverter;
//import com.benja.productosRest.rest.repository.CategoriaRepository;
import com.benja.productosRest.rest.repository.ProductoRepository;
import com.benja.productosRest.rest.upload.StorageService;
import com.fasterxml.jackson.databind.JsonMappingException;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
// @CrossOrigin(origins = "http://localhost:9001", methods={RequestMethod.GET, RequestMethod.POST}) 
//CORS a nivel de clase
public class ProductoController {

	// final porque no será modificado
	private final ProductoRepository productoRepositorio;
	private final ProductoDTOConverter productoDTOConverter;
	private final StorageService storageService;

	// private final CategoriaRepository categoriaRepositorio;
	@Autowired
	// private final ProductoService productoService;
	/**
	 * Obtenemos todos los productos
	 * 
	 * @return
	 */
	// ReponseEntity<?> nos permite devolver cualquier valor distinto
	// de tipo responsEntity, entonces, devolvemos un notFound y un ok
	@GetMapping("/producto")
	public ResponseEntity<?> obtenerTodos() {
		List<Producto> result = productoRepositorio.findAll();
		if (result.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No hay productos registrados");
		} else {
			List<ProductoDTO> dtoList = result.stream().map(productoDTOConverter::convertToDto)
					.collect(Collectors.toList());
			return ResponseEntity.ok(dtoList);
		}
	}

	/**
	 * Obtenemos un producto en base a su ID
	 * 
	 * @param id
	 * @return Null si no encuentra el producto
	 */
	// @CrossOrigin(origins = "http://localhost:9001")

	@GetMapping("/producto/{id}")
	public Producto obtenerUno(@PathVariable Long id) {
//			Producto result = productoRepositorio.findById(id).orElse(null);
//			if (result == null){
//					return ResponseEntity.notFound().build();
//			} else {
//				return ResponseEntity.ok(result);
//			}
//		}
		try {

			return productoRepositorio.findById(id).orElseThrow(() -> new ProductoNotFoundException(id));
		} catch (ProductoNotFoundException ex) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, ex.getMessage());
		}
	}

	/**
	 * Insertamos un nuevo producto
	 * No es estrictamente necesario indicar que se trata de un archivo multiparte
	 * Aunque lo indicamos en consumes
	 * 
	 * @param nuevo
	 * @return producto insertado
	 */
	@PostMapping(value="/producto", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	// public ResponseEntity<Producto> nuevoProducto(@RequestBody Producto nuevo) {
	//public ResponseEntity<ProductoDTO> nuevoProducto(@RequestBody CreateProductoDTO nuevo) {
	public ResponseEntity<ProductoDTO> nuevoProducto(@RequestPart("nuevo") CreateProductoDTO nuevo, 
			@RequestPart("file") MultipartFile file) {
		
		String urlImagen = null;
		if (!file.isEmpty()) {
			String imagen = storageService.store(file);
			// Esto coge el nombre del fichero y genera la uri completa que añadiremos a la base de datos
			// Invocando al método que está definido como /files/{filename:.+}" y devolverá la url con todo ello
			// Si estamos montando el proyecto en localhost:8080 
			//y es imagen.jpg la url será http://localhost:800:/files/imagen.jpg
			urlImagen = MvcUriComponentsBuilder
					.fromMethodName(FicherosController.class, "serveFile", imagen, null)
					.build().toUriString();
		}
		
		
		// probablemente convertToProducto se tenga que modificar para añadir la url en el método
		nuevo.setImagen(urlImagen);
		ProductoDTO producto = productoDTOConverter
				.convertToDto(productoRepositorio.save(productoDTOConverter.convertToProducto(nuevo)));
		return ResponseEntity.status(HttpStatus.CREATED).body(producto);
		// O en vez de save, usar el servicio y el metodo parar salvar
	}

	/**
	 * @param editar
	 * @param id
	 * @return
	 */
	@PutMapping("/producto/{id}")
	public Producto editarProducto(@RequestBody Producto editar, @PathVariable Long id) {
		return productoRepositorio.findById(id).map(p -> {
			p.setNombre(editar.getNombre());
			p.setPrecio(editar.getPrecio());
			return productoRepositorio.save(p);
		}).orElseThrow(() -> new ProductoNotFoundException(id));
//			 .orElseGet(() -> {
//			 return ResponseEntity.notFound().build();
//		 });
	}

	/**
	 * Borra un producto del catálogo en base a su id
	 * 
	 * @param id
	 * @return
	 */
	@DeleteMapping("/producto/{id}")
	public ResponseEntity<?> borrarProducto(@PathVariable Long id) {
//		productoRepositorio.deleteById(id);
		Producto producto = productoRepositorio.findById(id).orElseThrow(() -> new ProductoNotFoundException(id));
		productoRepositorio.delete(producto);
		return ResponseEntity.noContent().build();
	}

}