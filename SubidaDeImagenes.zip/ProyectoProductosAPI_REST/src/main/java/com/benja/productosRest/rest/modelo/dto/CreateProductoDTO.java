package com.benja.productosRest.rest.modelo.dto;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class CreateProductoDTO {
	private String nombre;
	private float precio;
	private String imagen;
	private long categoriaId;

}
