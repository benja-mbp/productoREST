package com.benja.productosRest.rest.modelo.dto;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class ProductoDTO {
	
	private long id;
	private String nombre;
	private String imagen;
	// el converter recoge dentro de categoria el atributo nombre
	private String categoriaNombre;

}
