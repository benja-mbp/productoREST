package com.benja.productosRest.rest;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.benja.productosRest.rest.upload.StorageService;

@SpringBootApplication
public class ProyectoProductosApiRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoProductosApiRestApplication.class, args);
	}
	
	@Bean
	public CommandLineRunner init(StorageService storageService) {
		return args -> {
			// Inicializamos el servicio de ficheros
			storageService.deleteAll();
			storageService.init();

		};

	}


}
