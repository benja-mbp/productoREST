package com.benja.productosRest.rest.modelo.dto.converter;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import com.benja.productosRest.rest.modelo.Producto;
import com.benja.productosRest.rest.modelo.dto.CreateProductoDTO;
import com.benja.productosRest.rest.modelo.dto.ProductoDTO;

import lombok.RequiredArgsConstructor;

@Component @RequiredArgsConstructor
public class ProductoDTOConverter {

	private final ModelMapper modelMapper;
	public ProductoDTO convertToDto(Producto producto) {
		return modelMapper.map(producto, ProductoDTO.class);
	}
	
	public Producto convertToProducto(CreateProductoDTO productoDTO)
{
		return modelMapper.map(productoDTO, Producto.class);
		}
}
